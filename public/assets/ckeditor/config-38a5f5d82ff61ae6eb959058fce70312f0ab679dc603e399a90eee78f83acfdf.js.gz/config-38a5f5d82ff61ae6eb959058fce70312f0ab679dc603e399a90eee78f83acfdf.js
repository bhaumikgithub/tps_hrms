CKEDITOR.config.coreStyles_bold = { element : 'b', overrides : 'strong' };
